package com.max.chesscoach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class ChessService : Service() {

    companion object {
        const val ACTION_STOP = "com.max.chesscoach.STOP"
        const val CHANNEL = "chess_coach"
        const val LEARNED_FILE = "pieces_apprises.txt"
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var engine: Engine? = null
    private var arrowView: ArrowView? = null
    private var worker: Thread? = null

    @Volatile private var active = false
    private var closing = false
    private var screenW = 0
    private var screenH = 0

    private var bmp: Bitmap? = null
    private var pxArr: IntArray? = null
    private var bytes: ByteArray? = null
    private var stride = 0
    private var haveFrame = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (active) return START_NOT_STICKY

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")

        startInForeground()
        if (data == null) {
            shutdown()
            return START_NOT_STICKY
        }

        try {
            BoardReader.loadTemplates(assets.open("templates.txt").bufferedReader().use { it.readText() })
            val f = File(filesDir, LEARNED_FILE)
            if (f.exists()) BoardReader.importLearned(f.readText())
        } catch (e: Exception) {
            toast("Modèles de pièces introuvables")
            shutdown()
            return START_NOT_STICKY
        }

        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { shutdown() }
                }
            }, main)
            val r = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
            reader = r
            display = p.createVirtualDisplay(
                "chesscoach", screenW, screenH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
        } catch (e: Exception) {
            toast("Capture d'écran impossible : " + e.message)
            shutdown()
            return START_NOT_STICKY
        }

        try {
            setupOverlay(wm, dm)
        } catch (e: Exception) {
            toast("Impossible d'afficher la flèche : " + e.message)
            shutdown()
            return START_NOT_STICKY
        }

        active = true
        val t = Thread { loop() }
        t.isDaemon = true
        worker = t
        t.start()
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Chess Coach", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ChessService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Analyse d'échecs active")
            .setContentText("Une flèche indique le meilleur coup. Touche pour arrêter.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(stopIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupOverlay(wm: WindowManager, dm: DisplayMetrics) {
        val v = ArrowView(this)
        val lp = WindowManager.LayoutParams(
            dm.widthPixels, dm.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        // Android bloque les touches sous une fenêtre superposée plus opaque que 0,8.
        lp.alpha = 0.8f
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        arrowView = v
    }

    private fun onMain(block: () -> Unit) {
        val latch = CountDownLatch(1)
        main.post {
            try {
                block()
            } finally {
                latch.countDown()
            }
        }
        latch.await(2, TimeUnit.SECONDS)
    }

    private fun showArrow(a: FloatArray, b: FloatArray, sq: Float) {
        onMain { arrowView?.setArrow(a[0], a[1], b[0], b[1], sq) }
    }

    private fun hideArrow() {
        onMain { arrowView?.clearArrow() }
    }

    private var lastStatus = ""
    private fun status(s: String) {
        if (s == lastStatus) return
        lastStatus = s
        main.post { arrowView?.setStatus(s) }
    }

    private var debugSaved = false

    /** Enregistre une fois l'image capturée dans Téléchargements, pour le diagnostic. */
    private fun saveDebug(reason: String) {
        if (debugSaved || Build.VERSION.SDK_INT < 29) return
        val b = bmp ?: return
        debugSaved = true
        try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "chesscoach_diagnostic_${System.currentTimeMillis()}.png")
                put(MediaStore.Downloads.MIME_TYPE, "image/png")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            toast("Capture de diagnostic enregistrée dans Téléchargements ($reason)")
        } catch (e: Exception) {
            toast("Diagnostic non enregistré : " + e.message)
        }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    /** Récupère la dernière image de l'écran. */
    private fun grab(): Boolean {
        val r = reader ?: return false
        val img = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (img == null) return haveFrame
        try {
            val plane = img.planes[0]
            val bw = plane.rowStride / plane.pixelStride
            var b = bmp
            if (b == null || b.width != bw || b.height != screenH) {
                b?.recycle()
                b = Bitmap.createBitmap(bw, screenH, Bitmap.Config.ARGB_8888)
                bmp = b
                pxArr = IntArray(bw * screenH)
                bytes = ByteArray(bw * screenH * 4)
            }
            val arr = bytes!!
            val buf = plane.buffer
            buf.rewind()
            buf.get(arr, 0, minOf(buf.remaining(), arr.size))
            b!!.copyPixelsFromBuffer(ByteBuffer.wrap(arr))
            b.getPixels(pxArr!!, 0, bw, 0, 0, bw, screenH)
            stride = bw
            haveFrame = true
        } finally {
            img.close()
        }
        return true
    }

    private fun loop() {
        val path = applicationInfo.nativeLibraryDir + "/libstockfish.so"
        val eng = Engine(path)
        if (!File(path).exists() || !eng.start()) {
            toast("Moteur Stockfish introuvable ou impossible à lancer")
            main.post { shutdown() }
            return
        }
        engine = eng
        toast("Analyse automatique active. Ouvre Chess.com.")
        status("Moteur prêt – en attente de l'échiquier")
        var lostSince = 0L
        var lastSearch = 0L

        var shownSig: IntArray? = null
        var prevSig: IntArray? = null
        var lastFen: String? = null
        var lastMove: String? = null
        var arrowVisible = false

        while (active) {
            try {
                Thread.sleep(400)
                if (!grab()) { status("Aucune image capturée"); continue }
                val px = pxArr ?: continue
                // Recherche complète de l'échiquier au plus une fois par seconde (économise la batterie).
                val now = System.currentTimeMillis()
                val model = BoardReader.locate(px, stride, screenW, screenH, now - lastSearch > 1000)
                if (BoardReader.searchedLastCall) lastSearch = now
                if (model == null) {
                    status("Échiquier non trouvé")
                    if (lostSince == 0L) lostSince = System.currentTimeMillis()
                    else if (System.currentTimeMillis() - lostSince > 8000) saveDebug("échiquier non trouvé")
                    if (arrowVisible) {
                        hideArrow()
                        arrowVisible = false
                    }
                    shownSig = null
                    prevSig = null
                    continue
                }
                lostSince = 0L
                val sig = BoardReader.signature(px, stride, screenW, screenH, model)
                val shown = shownSig
                if (shown != null && !BoardReader.changed(shown, sig)) {
                    prevSig = sig
                    continue
                }
                val prev = prevSig
                if (prev == null || BoardReader.changed(prev, sig)) {
                    prevSig = sig
                    continue
                }

                // L'écran a changé puis s'est stabilisé : on relit l'échiquier sans la flèche.
                if (arrowVisible) {
                    hideArrow()
                    arrowVisible = false
                    Thread.sleep(300)
                    grab()
                }
                val px2 = pxArr ?: continue
                val pos = BoardReader.read(px2, stride, screenW, screenH, model)
                if (BoardReader.learnedDirty) {
                    BoardReader.learnedDirty = false
                    saveLearned()
                }
                if (pos == null) {
                    status("Lecture impossible : " + BoardReader.lastError)
                    saveDebug(BoardReader.lastError)
                    lastFen = null
                    lastMove = null
                    shownSig = BoardReader.signature(px2, stride, screenW, screenH, model)
                    prevSig = shownSig
                    continue
                }

                var move: String? = lastMove
                if (pos.fen != lastFen) {
                    if (!eng.isAlive()) eng.start()
                    status("Calcul…")
                    move = eng.bestMove(pos.fen, 900)
                    lastFen = pos.fen
                    lastMove = move
                }

                val side = if (pos.fen.contains(" w ")) "Blancs" else "Noirs"
                status(if (move != null) "Meilleur coup : $move ($side jouent)" else "Pas de coup trouvé")
                if (move != null) {
                    val a = pos.center(move.substring(0, 2))
                    val b = pos.center(move.substring(2, 4))
                    showArrow(a, b, pos.sq)
                    arrowVisible = true
                    Thread.sleep(300)
                    grab()
                }
                val px3 = pxArr ?: continue
                shownSig = BoardReader.signature(px3, stride, screenW, screenH, model)
                prevSig = shownSig
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                // on réessaie au tour suivant
            }
        }
    }

    /** Mémorise les pièces apprises sur la position de départ (survit au redémarrage). */
    private fun saveLearned() {
        try {
            File(filesDir, LEARNED_FILE).writeText(BoardReader.exportLearned())
            toast("Pièces de cet échiquier apprises ✓")
        } catch (_: Exception) {
        }
    }

    private fun shutdown() {
        if (closing) return
        closing = true
        active = false
        worker?.interrupt()
        try { engine?.stop() } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        arrowView?.let {
            try {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (_: Exception) {
            }
        }
        arrowView = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}

package com.max.chesscoach

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqCapture = 42
    private val reqNotif = 43

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(56, 140, 56, 56)
        col.setBackgroundColor(Color.parseColor("#1E1E1E"))

        val title = TextView(this)
        title.text = "Chess Coach Auto"
        title.textSize = 28f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER
        col.addView(title)

        val info = TextView(this)
        info.text = "1. Touche « Démarrer », autorise l'affichage par-dessus les autres applis, puis la capture d'écran (choisis « Écran entier »).\n\n" +
            "2. Ouvre ton échiquier (n'importe quel thème, n'importe quelle appli) : l'app le trouve toute seule et trace une flèche sur le meilleur coup.\n\n" +
            "Astuce : affiche une fois une partie en position de départ. L'app y apprend la forme exacte de tes pièces et les reconnaît ensuite à coup sûr.\n\n" +
            "Pour arrêter : touche la notification « Analyse d'échecs active » ou le bouton Arrêter."
        info.textSize = 16f
        info.setTextColor(Color.LTGRAY)
        info.setPadding(0, 48, 0, 48)
        col.addView(info)

        val start = Button(this)
        start.text = "Démarrer"
        start.setOnClickListener { begin() }
        col.addView(start)

        val stop = Button(this)
        stop.text = "Arrêter"
        stop.setOnClickListener {
            startService(Intent(this, ChessService::class.java).setAction(ChessService.ACTION_STOP))
        }
        col.addView(stop)

        setContentView(col)
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Autorise « Afficher par-dessus d'autres applis », puis reviens et touche Démarrer.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif) askCapture()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqCapture) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ChessService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "Capture d'écran refusée", Toast.LENGTH_SHORT).show()
        }
    }
}

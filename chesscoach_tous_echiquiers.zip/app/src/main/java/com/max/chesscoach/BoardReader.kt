package com.max.chesscoach

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Template(val type: Char, val white: Boolean, val grid: FloatArray)

/** Échiquier repéré à l'écran : coin haut-gauche (x, y), côté total, couleurs des cases. */
class BoardModel(
    val x: Float,
    val y: Float,
    val size: Float,
    val light: Int,
    val dark: Int
) {
    val sq: Float get() = size / 8f
}

class Position(
    val fen: String,
    val left: Float,
    val top: Float,
    val sq: Float,
    val whiteAtBottom: Boolean
) {
    /** Centre d'une case UCI (ex. "e2") en pixels écran. */
    fun center(square: String): FloatArray {
        val file = square[0] - 'a'
        val rank = square[1] - '1' + 1
        val col = if (whiteAtBottom) file else 7 - file
        val row = if (whiteAtBottom) 8 - rank else rank - 1
        return floatArrayOf(left + (col + 0.5f) * sq, top + (row + 0.5f) * sq)
    }
}

/**
 * Lecture d'un échiquier à l'écran, quel que soit le thème :
 *  - l'échiquier est cherché comme un damier 8x8 de deux couleurs alternées (taille et position libres) ;
 *  - une pièce = ce qui diffère de la couleur de fond de SA case (donc indépendant des couleurs du plateau) ;
 *  - dès qu'une position de départ s'affiche, l'app apprend la forme exacte des pièces affichées.
 */
object BoardReader {
    private const val N = 24      // taille des modèles de pièces
    private const val G = 48      // grille d'analyse d'une case

    private var builtin: List<Template> = emptyList()
    private var learned: List<Template> = emptyList()
    private var lumThreshold = 140f

    /** Raison du dernier échec de lecture (diagnostic). */
    @Volatile var lastError: String = ""

    /** Vrai quand de nouvelles pièces viennent d'être apprises (à sauvegarder). */
    @Volatile var learnedDirty = false

    /** Vrai si la dernière recherche complète de l'échiquier a eu lieu pendant l'appel à locate(). */
    var searchedLastCall = false

    private var board: BoardModel? = null
    private var orientation: Boolean? = null

    val hasLearned: Boolean get() = learned.isNotEmpty()

    // ------------------------------------------------------------------ couleurs

    private fun red(p: Int) = (p shr 16) and 255
    private fun grn(p: Int) = (p shr 8) and 255
    private fun blu(p: Int) = p and 255
    private fun lum(p: Int) = (299 * red(p) + 587 * grn(p) + 114 * blu(p)) / 1000
    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    fun dist(a: Int, b: Int): Int =
        abs(red(a) - red(b)) + abs(grn(a) - grn(b)) + abs(blu(a) - blu(b))

    private class Img(val px: IntArray, val stride: Int, val w: Int, val h: Int) {
        fun at(x: Float, y: Float): Int {
            val xi = x.toInt().coerceIn(0, w - 1)
            val yi = y.toInt().coerceIn(0, h - 1)
            return px[yi * stride + xi]
        }

        /** Moyenne 3x3 autour du point (atténue le grain du bois, l'antialiasing…). */
        fun avg(x: Float, y: Float): Int {
            val xi = x.toInt().coerceIn(1, w - 2)
            val yi = y.toInt().coerceIn(1, h - 2)
            var r = 0; var g = 0; var b = 0
            for (dy in -1..1) {
                val base = (yi + dy) * stride + xi
                for (dx in -1..1) {
                    val p = px[base + dx]
                    r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255
                }
            }
            return (0xFF shl 24) or ((r / 9) shl 16) or ((g / 9) shl 8) or (b / 9)
        }
    }

    // ------------------------------------------------------------------ modèles

    fun loadTemplates(text: String) {
        builtin = parseTemplates(text).first
    }

    fun importLearned(text: String) {
        val (list, lumThr) = parseTemplates(text)
        if (list.size == 12) {
            learned = list
            if (lumThr != null) lumThreshold = lumThr
        }
    }

    fun exportLearned(): String {
        val sb = StringBuilder()
        sb.append("lum ").append(lumThreshold.toInt()).append('\n')
        for (t in learned) {
            sb.append(t.type).append(' ').append(if (t.white) 'w' else 'b').append(' ')
            for (v in t.grid) sb.append(Character.forDigit((v * 15f + 0.5f).toInt().coerceIn(0, 15), 16))
            sb.append('\n')
        }
        return sb.toString()
    }

    fun forgetLearned() {
        learned = emptyList()
        lumThreshold = 140f
    }

    private fun parseTemplates(text: String): Pair<List<Template>, Float?> {
        val list = ArrayList<Template>()
        var lumThr: Float? = null
        for (line in text.lineSequence()) {
            val p = line.trim().split(" ")
            if (p.size == 2 && p[0] == "lum") { lumThr = p[1].toFloatOrNull(); continue }
            if (p.size != 3 || p[2].length != N * N) continue
            val g = FloatArray(N * N) { Character.digit(p[2][it], 16) / 15f }
            // Les modèles sont recadrés comme les pièces lues : la taille et la position
            // de la pièce dans sa case n'ont plus d'importance.
            val mask = BooleanArray(N * N) { g[it] > 0.5f }
            list.add(Template(p[0][0].lowercaseChar(), p[1] == "w", normalize(mask, N) ?: g))
        }
        return Pair(list, lumThr)
    }

    // ------------------------------------------------------------------ localisation

    private class Fit(val corner: Float, val edge: Float, val light: Int, val dark: Int, val contrast: Int) {
        val total: Float get() = corner + edge + contrast * 1e-4f
    }

    private val samples = IntArray(256)

    /** Score rapide d'un damier candidat (2 échantillons par case). */
    private fun coarseScore(img: Img, x0: Float, y0: Float, b: Float): Float {
        val s = b / 8f
        var lr = 0; var lg = 0; var lb = 0; var dr = 0; var dg = 0; var db = 0
        var k = 0
        for (r in 0..7) {
            val ya = y0 + (r + 0.1f) * s
            val yb = y0 + (r + 0.9f) * s
            for (c in 0..7) {
                val p1 = img.at(x0 + (c + 0.1f) * s, ya)
                val p2 = img.at(x0 + (c + 0.9f) * s, yb)
                samples[k++] = p1; samples[k++] = p2
                if ((r + c) and 1 == 0) {
                    lr += red(p1) + red(p2); lg += grn(p1) + grn(p2); lb += blu(p1) + blu(p2)
                } else {
                    dr += red(p1) + red(p2); dg += grn(p1) + grn(p2); db += blu(p1) + blu(p2)
                }
            }
        }
        val mL = rgb(lr / 64, lg / 64, lb / 64)
        val mD = rgb(dr / 64, dg / 64, db / 64)
        if (lum(mL) <= lum(mD)) return -1f          // la case en haut à gauche est toujours claire
        val contrast = dist(mL, mD)
        if (contrast < 30) return -1f
        var spread = 0
        k = 0
        for (r in 0..7) for (c in 0..7) {
            val m = if ((r + c) and 1 == 0) mL else mD
            spread += dist(samples[k++], m) + dist(samples[k++], m)
        }
        return contrast - 2f * spread / 128f
    }

    /**
     * Score précis : coins de chaque case cohérents avec la couleur attendue,
     * et vrai changement de couleur de part et d'autre de chaque ligne de la grille.
     */
    private fun fineFit(img: Img, x0: Float, y0: Float, b: Float, dFrac: Float, minD: Float): Fit? {
        val s = b / 8f
        val i = 0.07f
        var k = 0
        var lr = 0; var lg = 0; var lb = 0; var dr = 0; var dg = 0; var db = 0
        for (r in 0..7) for (c in 0..7) {
            val light = (r + c) and 1 == 0
            for (q in 0..3) {
                val u = if (q and 1 == 0) c + i else c + 1 - i
                val v = if (q < 2) r + i else r + 1 - i
                val p = img.at(x0 + u * s, y0 + v * s)
                samples[k++] = p
                if (light) { lr += red(p); lg += grn(p); lb += blu(p) } else { dr += red(p); dg += grn(p); db += blu(p) }
            }
        }
        var mL = rgb(lr / 128, lg / 128, lb / 128)
        var mD = rgb(dr / 128, dg / 128, db / 128)
        // Deuxième passe : on ignore les échantillons aberrants (surlignage, coordonnées, pièces).
        lr = 0; lg = 0; lb = 0; dr = 0; dg = 0; db = 0
        var nl = 0; var nd = 0
        k = 0
        for (r in 0..7) for (c in 0..7) {
            val light = (r + c) and 1 == 0
            for (q in 0..3) {
                val p = samples[k++]
                val own = if (light) mL else mD
                val oth = if (light) mD else mL
                if (dist(p, own) > dist(p, oth)) continue
                if (light) { lr += red(p); lg += grn(p); lb += blu(p); nl++ } else { dr += red(p); dg += grn(p); db += blu(p); nd++ }
            }
        }
        if (nl < 32 || nd < 32) return null
        mL = rgb(lr / nl, lg / nl, lb / nl)
        mD = rgb(dr / nd, dg / nd, db / nd)
        if (lum(mL) <= lum(mD)) return null
        val contrast = dist(mL, mD)
        if (contrast < 30) return null

        var match = 0
        k = 0
        for (r in 0..7) for (c in 0..7) {
            val light = (r + c) and 1 == 0
            val own = if (light) mL else mD
            val oth = if (light) mD else mL
            for (q in 0..3) {
                val p = samples[k++]
                val d = dist(p, own)
                if (d < dist(p, oth) && d * 2 < contrast) match++
            }
        }

        val d = max(minD, s * dFrac)
        var pass = 0
        for (line in 1..7) {
            val lp = line * s
            for (r in 0..7) {
                for (t in 0..1) {
                    val along = (r + if (t == 0) 0.12f else 0.88f) * s
                    // ligne verticale
                    val a1 = img.at(x0 + lp - d, y0 + along)
                    val b1 = img.at(x0 + lp + d, y0 + along)
                    if (dist(a1, b1) * 2 > contrast) pass++
                    // ligne horizontale
                    val a2 = img.at(x0 + along, y0 + lp - d)
                    val b2 = img.at(x0 + along, y0 + lp + d)
                    if (dist(a2, b2) * 2 > contrast) pass++
                }
            }
        }
        return Fit(match / 256f, pass / 224f, mL, mD, contrast)
    }

    private fun downscale(img: Img, f: Int): Img {
        val w2 = img.w / f
        val h2 = img.h / f
        val out = IntArray(w2 * h2)
        val step = max(1, f / 4)
        for (y in 0 until h2) for (x in 0 until w2) {
            var r = 0; var g = 0; var b = 0; var n = 0
            var yy = y * f
            while (yy < y * f + f) {
                val base = yy * img.stride
                var xx = x * f
                while (xx < x * f + f) {
                    val p = img.px[base + xx]
                    r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; n++
                    xx += step
                }
                yy += step
            }
            out[y * w2 + x] = rgb(r / n, g / n, b / n)
        }
        return Img(out, w2, w2, h2)
    }

    private fun search(full: Img): BoardModel? {
        val f = max(1, full.w / 160)
        val small = downscale(full, f)
        val maxB = min(small.w, small.h)
        val minB = (maxB * 0.4f).toInt()

        // 1) recherche grossière sur l'image réduite
        var best = -1f; var bx = 0; var by = 0; var bb = 0
        var b = maxB
        while (b >= minB) {
            var y = 0
            while (y + b <= small.h) {
                var x = 0
                while (x + b <= small.w) {
                    val sc = coarseScore(small, x.toFloat(), y.toFloat(), b.toFloat())
                    if (sc > best) { best = sc; bx = x; by = y; bb = b }
                    x += 2
                }
                y += 2
            }
            b -= 2
        }
        if (best < 20f) return null

        // 2) affinage sur l'image réduite
        var bestFit = -1f; var mx = bx.toFloat(); var my = by.toFloat(); var mb = bb.toFloat()
        for (db in -3..3) for (dy in -3..3) for (dx in -3..3) {
            val x = bx + dx; val y = by + dy; val s = bb + db
            if (x < 0 || y < 0 || x + s > small.w || y + s > small.h) continue
            val fit = fineFit(small, x.toFloat(), y.toFloat(), s.toFloat(), 0.08f, 1f) ?: continue
            if (fit.total > bestFit) { bestFit = fit.total; mx = x.toFloat(); my = y.toFloat(); mb = s.toFloat() }
        }
        if (bestFit < 0f) return null

        // 3) affinage à pleine résolution, puis au pixel près
        var cx = mx * f; var cy = my * f; var cb = mb * f
        val rad = (f * 1.5f).toInt() + 2
        for (pass in 0..1) {
            val step = if (pass == 0) 2 else 1
            val r = if (pass == 0) rad else 2
            var top = -1f
            val cands = ArrayList<FloatArray>()
            var db = -2 * r
            while (db <= 2 * r) {
                var dy = -r
                while (dy <= r) {
                    var dx = -r
                    while (dx <= r) {
                        val x = cx + dx; val y = cy + dy; val s = cb + db
                        if (x >= 0 && y >= 0 && x + s <= full.w && y + s <= full.h) {
                            val fit = fineFit(full, x, y, s, 0.035f, 2f)
                            if (fit != null) {
                                cands.add(floatArrayOf(fit.total, x, y, s))
                                if (fit.total > top) top = fit.total
                            }
                        }
                        dx += step
                    }
                    dy += step
                }
                db += step
            }
            if (top < 0f) return null
            // centre du plateau de meilleurs scores (précision sub-pixel)
            var sx = 0f; var sy = 0f; var sb = 0f; var n = 0
            for (cnd in cands) if (cnd[0] >= top - 0.01f) { sx += cnd[1]; sy += cnd[2]; sb += cnd[3]; n++ }
            cx = sx / n; cy = sy / n; cb = sb / n
        }
        val fit = fineFit(full, cx, cy, cb, 0.035f, 2f) ?: return null
        if (fit.corner < 0.8f || fit.edge < 0.75f) return null
        return BoardModel(cx, cy, cb, fit.light, fit.dark)
    }

    /**
     * Renvoie l'échiquier visible : vérifie rapidement celui déjà connu,
     * sinon (si allowSearch) le recherche sur tout l'écran.
     */
    fun locate(px: IntArray, stride: Int, w: Int, h: Int, allowSearch: Boolean): BoardModel? {
        searchedLastCall = false
        val img = Img(px, stride, w, h)
        val cur = board
        if (cur != null) {
            val fit = fineFit(img, cur.x, cur.y, cur.size, 0.035f, 2f)
            if (fit != null && fit.corner >= 0.7f && fit.edge >= 0.6f &&
                dist(fit.light, cur.light) * 4 < fit.contrast &&
                dist(fit.dark, cur.dark) * 4 < fit.contrast
            ) return cur
        }
        if (!allowSearch) return null
        searchedLastCall = true
        val found = search(img)
        board = found
        return found
    }

    /** Signature légère de l'échiquier : [position, 64 cases x 36 échantillons de luminance]. */
    fun signature(px: IntArray, stride: Int, w: Int, h: Int, m: BoardModel): IntArray {
        val img = Img(px, stride, w, h)
        val s = m.sq
        val out = IntArray(1 + 64 * 36)
        out[0] = m.x.toInt() * 7919 + m.y.toInt() * 31 + m.size.toInt()
        var k = 1
        for (r in 0..7) for (c in 0..7) {
            for (i in 0 until 6) for (j in 0 until 6) {
                out[k++] = lum(img.at(m.x + (c + (j * 2 + 1) / 12f) * s, m.y + (r + (i * 2 + 1) / 12f) * s))
            }
        }
        return out
    }

    fun changed(a: IntArray, b: IntArray): Boolean {
        if (a[0] != b[0]) return true
        for (sqi in 0 until 64) {
            var d = 0
            val base = 1 + sqi * 36
            for (i in 0 until 36) d += abs(a[base + i] - b[base + i])
            if (d >= 288) return true
        }
        return false
    }

    // ------------------------------------------------------------------ analyse d'une case

    private class SquareInfo(
        val occupied: Boolean,
        val medLum: Float,
        val grid: FloatArray?,
        val highlight: Int        // écart de la couleur de fond par rapport à la normale (0 = aucun)
    )

    private val maskBuf = BooleanArray(G * G)
    private val outside = BooleanArray(G * G)
    private val comp = BooleanArray(G * G)
    private val label = IntArray(G * G)
    private val lumBuf = IntArray(G * G)
    private val pieceCell = BooleanArray(G * G)
    private val queue = IntArray(G * G)

    private fun analyse(img: Img, m: BoardModel, r: Int, c: Int): SquareInfo {
        val s = m.sq
        val x0 = m.x + c * s
        val y0 = m.y + r * s
        val contrast = dist(m.light, m.dark)

        // Fond réel de la case (gère le surlignage) : le plus « central » des 4 coins.
        val i = 0.06f
        val corners = intArrayOf(
            img.avg(x0 + i * s, y0 + i * s), img.avg(x0 + (1 - i) * s, y0 + i * s),
            img.avg(x0 + i * s, y0 + (1 - i) * s), img.avg(x0 + (1 - i) * s, y0 + (1 - i) * s)
        )
        var bg = corners[0]; var bestSum = Int.MAX_VALUE
        for (a in corners) {
            var sum = 0
            for (b in corners) sum += dist(a, b)
            if (sum < bestSum) { bestSum = sum; bg = a }
        }
        val expected = if ((r + c) and 1 == 0) m.light else m.dark
        val dev = dist(bg, expected)
        val highlight = if (dev > max(30, contrast / 4)) dev else 0

        // Seuil adapté au grain de la case (bois, textures) mesuré dans ses 4 coins.
        val noise = IntArray(4)
        val pw = max(2f, s * 0.1f)
        for (q in 0..3) {
            val px0 = x0 + (if (q and 1 == 0) 0.03f * s else (0.97f * s - pw))
            val py0 = y0 + (if (q < 2) 0.03f * s else (0.97f * s - pw))
            var mx = 0
            var yy = 0f
            while (yy < pw) {
                var xx = 0f
                while (xx < pw) {
                    val d = dist(img.at(px0 + xx, py0 + yy), bg)
                    if (d > mx) mx = d
                    xx += 1f
                }
                yy += 1f
            }
            noise[q] = mx
        }
        noise.sort()
        val thr = max((contrast * 0.25f).toInt().coerceIn(30, 60), noise[1] * 3 / 2 + 10)
        val margin = 2
        // Chaque cellule garde l'écart MAXIMAL de ses pixels : les contours fins ne sont pas perdus.
        val cell = s / G
        for (gy in 0 until G) {
            val ya = (y0 + gy * cell).toInt().coerceIn(0, img.h - 1)
            val yb = (y0 + (gy + 1) * cell).toInt().coerceIn(ya + 1, img.h)
            for (gx in 0 until G) {
                val idx = gy * G + gx
                val xa = (x0 + gx * cell).toInt().coerceIn(0, img.w - 1)
                val xb = (x0 + (gx + 1) * cell).toInt().coerceIn(xa + 1, img.w)
                var maxD = 0; var lumSum = 0; var n = 0
                var sr = 0; var sg = 0; var sb = 0
                for (yy in ya until yb) {
                    val base = yy * img.stride
                    for (xx in xa until xb) {
                        val p = img.px[base + xx]
                        // léger lissage 2x2 : le grain pixel par pixel ne passe pas pour une pièce
                        val q1 = img.px[base + min(xx + 1, img.w - 1)]
                        val q2 = img.px[min(yy + 1, img.h - 1) * img.stride + xx]
                        val d = (dist(p, bg) * 2 + dist(q1, bg) + dist(q2, bg)) / 4
                        if (d > maxD) maxD = d
                        lumSum += lum(p); n++
                        sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
                    }
                }
                lumBuf[idx] = lumSum / n
                // cellule « vraiment pièce » : sa couleur moyenne diffère nettement du fond
                pieceCell[idx] = dist(rgb(sr / n, sg / n, sb / n), bg) > thr / 2
                maskBuf[idx] = gx >= margin && gy >= margin && gx < G - margin && gy < G - margin &&
                    maxD > thr
            }
        }

        // Remplit l'intérieur des pièces (pièces blanches proches de la couleur des cases claires).
        java.util.Arrays.fill(outside, false)
        var qh = 0; var qt = 0
        for (k in 0 until G) {
            for (idx in intArrayOf(k, (G - 1) * G + k, k * G, k * G + G - 1)) {
                if (!maskBuf[idx] && !outside[idx]) { outside[idx] = true; queue[qt++] = idx }
            }
        }
        while (qh < qt) {
            val idx = queue[qh++]
            val x = idx % G; val y = idx / G
            if (x > 0) push(idx - 1).let { if (it) queue[qt++] = idx - 1 }
            if (x < G - 1) push(idx + 1).let { if (it) queue[qt++] = idx + 1 }
            if (y > 0) push(idx - G).let { if (it) queue[qt++] = idx - G }
            if (y < G - 1) push(idx + G).let { if (it) queue[qt++] = idx + G }
        }

        // Plus grande composante connexe : élimine coordonnées, grain du bois, poussières.
        java.util.Arrays.fill(label, 0)
        var bestLabel = 0; var bestSize = 0; var cur = 0
        for (start in 0 until G * G) {
            if (outside[start] || label[start] != 0) continue
            cur++
            var h = 0; var t = 0
            queue[t++] = start; label[start] = cur
            while (h < t) {
                val idx = queue[h++]
                val x = idx % G; val y = idx / G
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= G || ny >= G) continue
                    val n = ny * G + nx
                    if (outside[n] || label[n] != 0) continue
                    label[n] = cur; queue[t++] = n
                }
            }
            if (t > bestSize) { bestSize = t; bestLabel = cur }
        }
        if (bestSize < G * G * 0.05f) return SquareInfo(false, 0f, null, highlight)

        var minY = G; var maxY = -1
        val hist = IntArray(256)
        var nHist = 0
        for (idx in 0 until G * G) {
            val inC = label[idx] == bestLabel
            comp[idx] = inC
            if (inC) {
                val y = idx / G
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                // le fond visible dans les trous de la pièce ne compte pas pour sa couleur
                if (pieceCell[idx]) { hist[lumBuf[idx]]++; nHist++ }
            }
        }
        if (maxY - minY + 1 < G * 0.3f || nHist < G * G * 0.03f) return SquareInfo(false, 0f, null, highlight)
        // Luminance du 70e centile : l'intérieur d'une pièce blanche est clair même si son contour est noir.
        var acc = 0; var med = 0
        while (med < 255 && acc + hist[med] <= nHist * 7 / 10) { acc += hist[med]; med++ }
        val grid = normalize(comp, G) ?: return SquareInfo(false, 0f, null, highlight)
        return SquareInfo(true, med.toFloat(), grid, highlight)
    }

    private fun push(idx: Int): Boolean {
        if (maskBuf[idx] || outside[idx]) return false
        outside[idx] = true
        return true
    }

    /** Recadre une silhouette dans une grille N x N (centrée, proportions conservées). */
    private fun normalize(mask: BooleanArray, size: Int): FloatArray? {
        var minX = size; var minY = size; var maxX = -1; var maxY = -1
        for (y in 0 until size) for (x in 0 until size) if (mask[y * size + x]) {
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        if (maxX < 0) return null
        val sc = max(maxX - minX + 1, maxY - minY + 1).toFloat()
        val cx = (minX + maxX + 1) / 2f
        val cy = (minY + maxY + 1) / 2f
        val out = FloatArray(N * N)
        for (ty in 0 until N) for (tx in 0 until N) {
            var v = 0
            for (sy in 0..1) for (sx in 0..1) {
                val fx = cx + (tx + 0.25f + sx * 0.5f - N / 2f) * sc / N
                val fy = cy + (ty + 0.25f + sy * 0.5f - N / 2f) * sc / N
                val ix = fx.toInt(); val iy = fy.toInt()
                if (fx >= 0 && fy >= 0 && ix < size && iy < size && mask[iy * size + ix]) v++
            }
            out[ty * N + tx] = v / 4f
        }
        return out
    }

    private fun classify(grid: FloatArray, white: Boolean, set: List<Template>): Char {
        var best = Float.MAX_VALUE
        var type = 'p'
        for (t in set) {
            if (t.white != white) continue
            var d = 0f
            for (i in 0 until N * N) {
                val e = grid[i] - t.grid[i]
                d += e * e
            }
            if (d < best) { best = d; type = t.type }
        }
        return if (white) type.uppercaseChar() else type.lowercaseChar()
    }

    // ------------------------------------------------------------------ apprentissage

    /** Si l'écran montre la position de départ, apprend les pièces affichées. Renvoie l'orientation ou null. */
    private fun learnFromStart(info: Array<SquareInfo>): Boolean? {
        for (r in 0..7) for (c in 0..7) {
            val occ = info[r * 8 + c].occupied
            if (occ != (r <= 1 || r >= 6)) return null
        }
        var top = 0f; var bottom = 0f
        for (c in 0..7) {
            top += info[c].medLum + info[8 + c].medLum
            bottom += info[48 + c].medLum + info[56 + c].medLum
        }
        top /= 16f; bottom /= 16f
        if (abs(top - bottom) < 40f) return null
        val whiteAtBottom = bottom > top
        // Les deux camps doivent être nettement séparés : seuil au milieu de l'écart.
        var minWhite = 255f; var maxBlack = 0f
        for (r in intArrayOf(0, 1, 6, 7)) for (c in 0..7) {
            val l = info[r * 8 + c].medLum
            if ((r >= 6) == whiteAtBottom) minWhite = min(minWhite, l) else maxBlack = max(maxBlack, l)
        }
        if (minWhite - maxBlack < 15f) return null
        val thr = (minWhite + maxBlack) / 2f

        val back = "rnbqkbnr"
        val sums = HashMap<String, FloatArray>()
        val counts = HashMap<String, Int>()
        for (r in intArrayOf(0, 1, 6, 7)) for (c in 0..7) {
            val file = if (whiteAtBottom) c else 7 - c
            val type = if (r == 1 || r == 6) 'p' else back[file]
            val white = (r >= 6) == whiteAtBottom
            val key = "$type${if (white) 'w' else 'b'}"
            val g = info[r * 8 + c].grid ?: return null
            val acc = sums.getOrPut(key) { FloatArray(N * N) }
            for (i in 0 until N * N) acc[i] += g[i]
            counts[key] = (counts[key] ?: 0) + 1
        }
        val list = ArrayList<Template>()
        for ((key, acc) in sums) {
            val n = counts[key]!!.toFloat()
            list.add(Template(key[0], key[1] == 'w', FloatArray(N * N) { acc[it] / n }))
        }

        // Ne sauvegarde que si c'est nouveau (premier apprentissage ou autre jeu de pièces).
        var diff = Float.MAX_VALUE
        if (learned.size == 12) {
            diff = 0f
            for (t in list) {
                val old = learned.firstOrNull { it.type == t.type && it.white == t.white } ?: continue
                for (i in 0 until N * N) { val e = t.grid[i] - old.grid[i]; diff += e * e }
            }
            diff /= 12f
        }
        learned = list
        lumThreshold = thr
        if (diff > 6f) learnedDirty = true
        return whiteAtBottom
    }

    // ------------------------------------------------------------------ lecture complète

    /** Lit l'échiquier affiché à l'écran et renvoie la position (FEN), ou null. */
    fun read(px: IntArray, stride: Int, w: Int, h: Int, m: BoardModel): Position? {
        if (builtin.isEmpty() && learned.isEmpty()) { lastError = "modèles absents"; return null }
        val img = Img(px, stride, w, h)
        val info = Array(64) { analyse(img, m, it / 8, it % 8) }

        val startOrientation = learnFromStart(info)
        if (startOrientation != null) orientation = startOrientation

        var board: Array<CharArray>? = null
        for (set in listOf(learned, builtin)) {
            if (set.isEmpty()) continue
            val b = Array(8) { CharArray(8) { '.' } }
            var wK = 0; var bK = 0
            for (k in 0 until 64) {
                val sq = info[k]
                if (!sq.occupied) continue
                val ch = classify(sq.grid!!, sq.medLum > lumThreshold, set)
                b[k / 8][k % 8] = ch
                if (ch == 'K') wK++
                if (ch == 'k') bK++
            }
            if (wK == 1 && bK == 1) { board = b; break }
            lastError = "rois lus : $wK blanc, $bK noir"
        }
        if (board == null) return null

        val whiteAtBottom = startOrientation ?: chooseOrientation(board)

        // Plateau "absolu" : abs[0] = rang 8, abs[x][0] = colonne a.
        val abs = Array(8) { i ->
            CharArray(8) { j -> if (whiteAtBottom) board[i][j] else board[7 - i][7 - j] }
        }

        // Validation : une lecture impossible ne doit jamais partir au moteur.
        var wp = 0; var bp = 0; var wn = 0; var bn = 0
        for (i in 0..7) for (j in 0..7) {
            val ch = abs[i][j]
            if (ch == '.') continue
            if (ch.isUpperCase()) wn++ else bn++
            if (ch == 'P') wp++
            if (ch == 'p') bp++
            if ((ch == 'P' || ch == 'p') && (i == 0 || i == 7)) {
                lastError = "pion lu sur la dernière rangée"
                return null
            }
        }
        if (wp > 8 || bp > 8 || wn > 16 || bn > 16) { lastError = "trop de pièces lues"; return null }

        // Camp qui joue : l'inverse de la pièce qui vient d'arriver sur une case surlignée.
        var whiteToMove = true
        var bestHl = -1; var bestStrength = 0; var kingHl = -1
        for (k in 0 until 64) {
            val ch = board[k / 8][k % 8]
            if (ch == '.' || info[k].highlight == 0) continue
            if (ch == 'K' || ch == 'k') { kingHl = k; continue }
            if (info[k].highlight > bestStrength) { bestStrength = info[k].highlight; bestHl = k }
        }
        val mover = if (bestHl >= 0) bestHl else kingHl
        if (mover >= 0) whiteToMove = !board[mover / 8][mover % 8].isUpperCase()

        // Le camp qui ne joue pas ne peut pas être en échec : sinon on s'est trompé de camp.
        val wInCheck = inCheck(abs, true)
        val bInCheck = inCheck(abs, false)
        if (wInCheck && bInCheck) { lastError = "deux rois en échec"; return null }
        if (whiteToMove && bInCheck) whiteToMove = false
        if (!whiteToMove && wInCheck) whiteToMove = true

        val sb = StringBuilder()
        for (i in 0..7) {
            var empty = 0
            for (j in 0..7) {
                val ch = abs[i][j]
                if (ch == '.') empty++ else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(ch)
                }
            }
            if (empty > 0) sb.append(empty)
            if (i < 7) sb.append('/')
        }
        sb.append(if (whiteToMove) " w " else " b ")
        val cs = StringBuilder()
        if (abs[7][4] == 'K' && abs[7][7] == 'R') cs.append('K')
        if (abs[7][4] == 'K' && abs[7][0] == 'R') cs.append('Q')
        if (abs[0][4] == 'k' && abs[0][7] == 'r') cs.append('k')
        if (abs[0][4] == 'k' && abs[0][0] == 'r') cs.append('q')
        sb.append(if (cs.isEmpty()) "-" else cs.toString())
        sb.append(" - 0 1")

        return Position(sb.toString(), m.x, m.y, m.sq, whiteAtBottom)
    }

    /** Orientation : pions impossibles, puis position moyenne des camps, puis mémoire. */
    private fun chooseOrientation(b: Array<CharArray>): Boolean {
        // Blancs en bas : aucun pion blanc sur la rangée du bas (rang 1), ni pion noir en haut (rang 8).
        var okNormal = true; var okFlipped = true
        for (c in 0..7) {
            if (b[7][c] == 'P' || b[0][c] == 'p') okNormal = false
            if (b[0][c] == 'P' || b[7][c] == 'p') okFlipped = false
        }
        if (okNormal != okFlipped) { orientation = okNormal; return okNormal }

        var wSum = 0f; var wN = 0; var bSum = 0f; var bN = 0
        for (r in 0..7) for (c in 0..7) {
            val ch = b[r][c]
            if (ch == '.') continue
            if (ch.isUpperCase()) { wSum += r; wN++ } else { bSum += r; bN++ }
        }
        val diff = wSum / max(wN, 1) - bSum / max(bN, 1)
        val mem = orientation
        if (mem == null || abs(diff) >= 1.5f) {
            val o = diff >= 0f
            orientation = o
            return o
        }
        return mem
    }

    /** Le roi de cette couleur est-il attaqué ? (plateau absolu, abs[0] = rang 8) */
    private fun inCheck(b: Array<CharArray>, white: Boolean): Boolean {
        val king = if (white) 'K' else 'k'
        for (r in 0..7) for (c in 0..7) if (b[r][c] == king) return attacked(b, r, c, !white)
        return false
    }

    private fun attacked(b: Array<CharArray>, r: Int, c: Int, byWhite: Boolean): Boolean {
        fun at(rr: Int, cc: Int): Char = if (rr in 0..7 && cc in 0..7) b[rr][cc] else '#'
        fun own(ch: Char) = if (byWhite) ch else ch.lowercaseChar()
        // pions : un pion blanc attaque vers le haut (rangée d'indice plus petit)
        val pr = if (byWhite) r + 1 else r - 1
        if (at(pr, c - 1) == own('P') || at(pr, c + 1) == own('P')) return true
        val knight = arrayOf(intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
            intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1))
        for (d in knight) if (at(r + d[0], c + d[1]) == own('N')) return true
        for (dr in -1..1) for (dc in -1..1) {
            if (dr == 0 && dc == 0) continue
            if (at(r + dr, c + dc) == own('K')) return true
            val diag = dr != 0 && dc != 0
            var rr = r + dr; var cc = c + dc
            while (true) {
                val ch = at(rr, cc)
                if (ch == '#') break
                if (ch != '.') {
                    if (ch == own('Q') || ch == own(if (diag) 'B' else 'R')) return true
                    break
                }
                rr += dr; cc += dc
            }
        }
        return false
    }
}

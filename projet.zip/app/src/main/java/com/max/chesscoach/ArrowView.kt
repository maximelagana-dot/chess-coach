package com.max.chesscoach

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.hypot

/** Vue transparente qui dessine une flèche entre deux points de l'écran. */
class ArrowView(ctx: Context) : View(ctx) {
    private var x1 = 0f
    private var y1 = 0f
    private var x2 = 0f
    private var y2 = 0f
    private var thick = 20f
    private var has = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setArrow(ax: Float, ay: Float, bx: Float, by: Float, squareSize: Float) {
        x1 = ax; y1 = ay; x2 = bx; y2 = by
        thick = squareSize * 0.17f
        has = true
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!has) return
        val dx = x2 - x1
        val dy = y2 - y1
        val len = hypot(dx, dy)
        if (len < 1f) return
        val ux = dx / len
        val uy = dy / len
        val head = thick * 2.4f
        val bx = x2 - ux * head
        val by = y2 - uy * head

        paint.color = Color.argb(215, 30, 190, 90)
        paint.style = Paint.Style.FILL
        canvas.drawCircle(x1, y1, thick * 1.1f, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = thick
        paint.strokeCap = Paint.Cap.BUTT
        canvas.drawLine(x1, y1, bx, by, paint)

        val px = -uy
        val py = ux
        val path = Path()
        path.moveTo(x2, y2)
        path.lineTo(bx + px * head * 0.7f, by + py * head * 0.7f)
        path.lineTo(bx - px * head * 0.7f, by - py * head * 0.7f)
        path.close()
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)
    }
}

package com.max.chesscoach

/**
 * Règles minimales pour fabriquer une position valide à partir de l'écran.
 * Plateau "absolu" : index 0 = a8, 7 = h8, 56 = a1, 63 = h1.
 */
object Chess {

    fun toAbs(screen: CharArray, whiteBottom: Boolean): CharArray =
        CharArray(64) { i -> if (whiteBottom) screen[i] else screen[63 - i] }

    /** Les Blancs sont-ils en bas ? (null si impossible à dire) */
    fun guessWhiteBottom(screen: CharArray): Boolean? {
        var wSum = 0; var wN = 0; var bSum = 0; var bN = 0
        for (i in 0 until 64) {
            val ch = screen[i]
            if (ch == '.') continue
            if (ch.isUpperCase()) { wSum += i / 8; wN++ } else { bSum += i / 8; bN++ }
        }
        if (wN == 0 || bN == 0) return null
        return wSum.toFloat() / wN >= bSum.toFloat() / bN
    }

    fun pieceCount(b: CharArray): Int = b.count { it != '.' }

    /** Renvoie un message d'erreur si la position est impossible, sinon null. */
    fun validate(b: CharArray): String? {
        var wk = 0; var bk = 0; var wp = 0; var bp = 0; var wn = 0; var bn = 0
        for (i in 0 until 64) {
            when (val ch = b[i]) {
                '.' -> {}
                else -> {
                    if (ch.isUpperCase()) wn++ else bn++
                    when (ch) {
                        'K' -> wk++
                        'k' -> bk++
                        'P' -> { wp++; if (i < 8 || i >= 56) return "pion sur la 1re/8e rangée" }
                        'p' -> { bp++; if (i < 8 || i >= 56) return "pion sur la 1re/8e rangée" }
                    }
                }
            }
        }
        if (wk != 1 || bk != 1) return "rois lus : $wk blanc, $bk noir"
        if (wp > 8 || bp > 8 || wn > 16 || bn > 16) return "trop de pièces lues"
        val a = kingSq(b, true)
        val c = kingSq(b, false)
        if (Math.abs(a / 8 - c / 8) <= 1 && Math.abs(a % 8 - c % 8) <= 1) return "rois côte à côte"
        return null
    }

    fun kingSq(b: CharArray, white: Boolean): Int = b.indexOf(if (white) 'K' else 'k')

    private fun at(b: CharArray, r: Int, c: Int): Char =
        if (r in 0..7 && c in 0..7) b[r * 8 + c] else '#'

    private val knight = arrayOf(
        intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
        intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1)
    )
    private val straight = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
    private val diagonal = arrayOf(intArrayOf(1, 1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(-1, -1))

    /** La case est-elle attaquée par le camp indiqué ? */
    fun attacked(b: CharArray, sq: Int, byWhite: Boolean): Boolean {
        val r = sq / 8
        val c = sq % 8
        val pawn = if (byWhite) 'P' else 'p'
        val pr = if (byWhite) r + 1 else r - 1 // les pions blancs montent vers l'index 0
        if (at(b, pr, c - 1) == pawn || at(b, pr, c + 1) == pawn) return true
        val n = if (byWhite) 'N' else 'n'
        for (o in knight) if (at(b, r + o[0], c + o[1]) == n) return true
        val k = if (byWhite) 'K' else 'k'
        for (dr in -1..1) for (dc in -1..1) {
            if ((dr != 0 || dc != 0) && at(b, r + dr, c + dc) == k) return true
        }
        val rook = if (byWhite) 'R' else 'r'
        val bishop = if (byWhite) 'B' else 'b'
        val queen = if (byWhite) 'Q' else 'q'
        for (d in straight) {
            var rr = r + d[0]; var cc = c + d[1]
            while (true) {
                val ch = at(b, rr, cc)
                if (ch == '#') break
                if (ch != '.') { if (ch == rook || ch == queen) return true; break }
                rr += d[0]; cc += d[1]
            }
        }
        for (d in diagonal) {
            var rr = r + d[0]; var cc = c + d[1]
            while (true) {
                val ch = at(b, rr, cc)
                if (ch == '#') break
                if (ch != '.') { if (ch == bishop || ch == queen) return true; break }
                rr += d[0]; cc += d[1]
            }
        }
        return false
    }

    fun inCheck(b: CharArray, white: Boolean): Boolean {
        val k = kingSq(b, white)
        return k >= 0 && attacked(b, k, !white)
    }

    /** Couleur du camp qui vient de jouer, déduite des cases qui ont changé (null si inconnu). */
    fun moverFromDiff(prev: CharArray?, now: CharArray): Boolean? {
        if (prev == null) return null
        var mover: Boolean? = null
        for (i in 0 until 64) {
            val ch = now[i]
            if (ch == '.' || ch == prev[i]) continue
            val white = ch.isUpperCase()
            if (mover == null) mover = white else if (mover != white) return null
        }
        return mover
    }

    /** Case de prise en passant après une poussée de deux cases, ou "-". */
    fun epSquare(prev: CharArray?, now: CharArray, whiteToMove: Boolean): String {
        if (prev == null) return "-"
        for (c in 0..7) {
            if (whiteToMove) {
                // un pion noir vient de passer de la 7e (ligne 1) à la 5e (ligne 3)
                if (prev[8 + c] == 'p' && now[8 + c] == '.' && prev[24 + c] != 'p' && now[24 + c] == 'p' && now[16 + c] == '.')
                    return "${'a' + c}6"
            } else {
                if (prev[48 + c] == 'P' && now[48 + c] == '.' && prev[32 + c] != 'P' && now[32 + c] == 'P' && now[40 + c] == '.')
                    return "${'a' + c}3"
            }
        }
        return "-"
    }

    fun fen(b: CharArray, whiteToMove: Boolean, ep: String): String {
        val sb = StringBuilder()
        for (r in 0..7) {
            var empty = 0
            for (c in 0..7) {
                val ch = b[r * 8 + c]
                if (ch == '.') empty++ else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(ch)
                }
            }
            if (empty > 0) sb.append(empty)
            if (r < 7) sb.append('/')
        }
        sb.append(if (whiteToMove) " w " else " b ")
        val cs = StringBuilder()
        if (b[60] == 'K' && b[63] == 'R') cs.append('K')
        if (b[60] == 'K' && b[56] == 'R') cs.append('Q')
        if (b[4] == 'k' && b[7] == 'r') cs.append('k')
        if (b[4] == 'k' && b[0] == 'r') cs.append('q')
        sb.append(if (cs.isEmpty()) "-" else cs.toString())
        sb.append(' ').append(ep).append(" 0 1")
        return sb.toString()
    }
}

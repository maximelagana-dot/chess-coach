package com.max.chesscoach

import android.content.Context

class Template(val type: Char, val white: Boolean, val grid: FloatArray)

/** Échiquier tel qu'il apparaît à l'écran (case 0 = en haut à gauche). */
class ScreenBoard(
    val cells: CharArray,          // 64 cases, '.' = vide, majuscule = blanc
    val highlighted: BooleanArray, // cases surlignées (dernier coup)
    val top: Int,
    val sq: Float
) {
    val key: String = String(cells)
}

/**
 * Lit l'échiquier Chess.com (thème bois) dans une image de l'écran.
 * Les pixels sont au format RGBA rangé en entier little-endian : r = p and 255.
 */
object BoardReader {
    private const val N = 24
    private const val NN = N * N
    private var templates: List<Template> = emptyList()

    @Volatile var lastError: String = ""

    private var lastTop = -1

    fun loadTemplates(ctx: Context) {
        val list = ArrayList<Template>()
        ctx.assets.open("templates.txt").bufferedReader().useLines { lines ->
            for (line in lines) {
                val p = line.trim().split(" ")
                if (p.size != 3 || p[2].length != NN) continue
                val g = FloatArray(NN) { Character.digit(p[2][it], 16) / 15f }
                list.add(Template(p[0][0], p[1] == "w", g))
            }
        }
        templates = list
    }

    private fun red(p: Int) = p and 255
    private fun green(p: Int) = (p ushr 8) and 255
    private fun blue(p: Int) = (p ushr 16) and 255

    private fun isWood(p: Int): Boolean {
        val r = red(p)
        val g = green(p)
        val b = blue(p)
        val lum = (299 * r + 587 * g + 114 * b) / 1000
        return r - b >= 40 && r >= g && lum in 50..250
    }

    private fun boardAt(px: IntArray, stride: Int, w: Int, y: Int): Boolean =
        isWood(px[y * stride + 2]) &&
            isWood(px[y * stride + w - 3]) &&
            isWood(px[(y + w - 3) * stride + 2]) &&
            isWood(px[(y + w - 3) * stride + w - 3])

    /** Ordonnée du haut de l'échiquier (il occupe toute la largeur), ou -1. */
    private fun findTop(px: IntArray, stride: Int, w: Int, h: Int): Int {
        val last = h - w
        if (last <= 0) return -1
        // Essai rapide : même position qu'à l'image précédente.
        val t = lastTop
        if (t in 0 until last && boardAt(px, stride, w, t) &&
            (t == 0 || !boardAt(px, stride, w, t - 1))
        ) return t
        for (y in 0 until last) {
            if (boardAt(px, stride, w, y)) {
                lastTop = y
                return y
            }
        }
        lastTop = -1
        return -1
    }

    // Tampons réutilisés (lecture faite par un seul thread).
    private val cnt = IntArray(NN)
    private val tot = IntArray(NN)
    private val area = IntArray(NN)
    private val grid = FloatArray(NN)
    private val use = BooleanArray(NN)

    /**
     * Analyse une case. Les pixels de la flèche verte sont ignorés pour
     * que la flèche affichée ne gêne pas la lecture.
     */
    private fun classifySquare(
        px: IntArray, stride: Int, x0: Int, y0: Int, x1: Int, y1: Int,
        lab: Int, skipTopLeft: Boolean, skipBottomRight: Boolean
    ): Char {
        java.util.Arrays.fill(cnt, 0)
        java.util.Arrays.fill(tot, 0)
        java.util.Arrays.fill(area, 0)
        val ws = x1 - x0
        val hs = y1 - y0
        var masked = 0
        var valid = 0
        var lumSum = 0L
        for (dy in 0 until hs) {
            val gi = dy * N / hs
            val rowBase = (y0 + dy) * stride + x0
            for (dx in 0 until ws) {
                val idx = gi * N + dx * N / ws
                area[idx]++
                if (skipTopLeft && dx < lab && dy < lab) continue
                if (skipBottomRight && dx >= ws - lab && dy >= hs - lab) continue
                val p = px[rowBase + dx]
                val r = red(p)
                val g = green(p)
                val b = blue(p)
                if (g > r + 25 && g > b + 25) continue // pixel de la flèche
                tot[idx]++
                valid++
                val mx = maxOf(r, maxOf(g, b))
                val mn = minOf(r, minOf(g, b))
                val lum = (299 * r + 587 * g + 114 * b) / 1000
                val sat = (mx - mn) * 100 / maxOf(mx, 1)
                if (sat < 26 || lum < 55) {
                    cnt[idx]++
                    masked++
                    lumSum += lum
                }
            }
        }
        if (valid == 0) return '.'
        if (masked.toFloat() / valid < 0.05f) return '.'
        for (i in 0 until NN) {
            grid[i] = if (tot[i] == 0) 0f else cnt[i].toFloat() / tot[i]
            use[i] = tot[i] * 2 >= area[i]
        }
        val white = lumSum.toFloat() / masked > 110f
        var best = Float.MAX_VALUE
        var type = 'p'
        for (t in templates) {
            if (t.white != white) continue
            var d = 0f
            val tg = t.grid
            for (i in 0 until NN) {
                if (!use[i]) continue
                val e = grid[i] - tg[i]
                d += e * e
            }
            if (d < best) {
                best = d
                type = t.type
            }
        }
        return if (white) type.uppercaseChar() else type.lowercaseChar()
    }

    private fun isHighlight(p: Int): Boolean =
        green(p) - blue(p) > 55 && red(p) > 150 && red(p) >= green(p)

    /** Lit l'échiquier affiché, ou null s'il n'y en a pas. */
    fun read(px: IntArray, stride: Int, w: Int, h: Int): ScreenBoard? {
        if (templates.isEmpty()) { lastError = "modèles absents"; return null }
        val top = findTop(px, stride, w, h)
        if (top < 0) { lastError = "échiquier non trouvé"; return null }
        val sq = w / 8f
        if (top + 8 * sq > h) { lastError = "échiquier coupé"; return null }

        val cells = CharArray(64)
        val hl = BooleanArray(64)
        val lab = (sq * 34f / 135f).toInt()
        val m = (sq * 12f / 135f).toInt().coerceAtLeast(2)

        for (r in 0..7) for (c in 0..7) {
            val x0 = Math.round(c * sq)
            val x1 = minOf(Math.round((c + 1) * sq), w)
            val y0 = top + Math.round(r * sq)
            val y1 = top + Math.round((r + 1) * sq)
            cells[r * 8 + c] = classifySquare(px, stride, x0, y0, x1, y1, lab, c == 0, r == 7)
            hl[r * 8 + c] =
                isHighlight(px[(y1 - m) * stride + x0 + m]) ||
                isHighlight(px[(y0 + m) * stride + x1 - m]) ||
                isHighlight(px[(y1 - m) * stride + x1 - m])
        }
        return ScreenBoard(cells, hl, top, sq)
    }
}

package com.max.chesscoach

import android.content.Context

class Template(val type: Char, val white: Boolean, val grid: FloatArray)

class Position(
    val fen: String,
    val top: Int,
    val sq: Int,
    val whiteAtBottom: Boolean
) {
    /** Centre d'une case UCI (ex. "e2") en pixels écran. */
    fun center(square: String): FloatArray {
        val file = square[0] - 'a'
        val rank = square[1] - '1' + 1
        val col = if (whiteAtBottom) file else 7 - file
        val row = if (whiteAtBottom) 8 - rank else rank - 1
        return floatArrayOf((col + 0.5f) * sq, top + (row + 0.5f) * sq)
    }
}

object BoardReader {
    private const val N = 24
    private var templates: List<Template> = emptyList()

    /** Raison du dernier échec de lecture (diagnostic). */
    @Volatile var lastError: String = ""

    fun loadTemplates(ctx: Context) {
        val list = ArrayList<Template>()
        ctx.assets.open("templates.txt").bufferedReader().useLines { lines ->
            for (line in lines) {
                val p = line.trim().split(" ")
                if (p.size != 3 || p[2].length != N * N) continue
                val g = FloatArray(N * N) { Character.digit(p[2][it], 16) / 15f }
                list.add(Template(p[0][0], p[1] == "w", g))
            }
        }
        templates = list
    }

    private fun isWood(p: Int): Boolean {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        val lum = (299 * r + 587 * g + 114 * b) / 1000
        return r - b >= 40 && r >= g && lum in 50..250
    }

    /** Ordonnée du haut de l'échiquier (il occupe toute la largeur), ou -1. */
    fun findBoardTop(px: IntArray, stride: Int, w: Int, h: Int): Int {
        val last = h - w
        for (y in 0 until last) {
            if (isWood(px[y * stride + 2]) &&
                isWood(px[y * stride + w - 3]) &&
                isWood(px[(y + w - 3) * stride + 2]) &&
                isWood(px[(y + w - 3) * stride + w - 3])
            ) return y
        }
        return -1
    }

    /** Signature légère de l'échiquier : [top, 64 cases x 36 échantillons de luminance]. */
    fun signature(px: IntArray, stride: Int, w: Int, h: Int): IntArray? {
        val top = findBoardTop(px, stride, w, h)
        if (top < 0) return null
        val s = w / 8
        if (top + 8 * s > h) return null
        val out = IntArray(1 + 64 * 36)
        out[0] = top
        var k = 1
        for (r in 0..7) for (c in 0..7) {
            for (i in 0 until 6) for (j in 0 until 6) {
                val x = c * s + (j * 2 + 1) * s / 12
                val y = top + r * s + (i * 2 + 1) * s / 12
                val p = px[y * stride + x]
                val rr = (p shr 16) and 255
                val gg = (p shr 8) and 255
                val bb = p and 255
                out[k++] = (299 * rr + 587 * gg + 114 * bb) / 1000
            }
        }
        return out
    }

    fun changed(a: IntArray, b: IntArray): Boolean {
        if (a[0] != b[0]) return true
        for (sqi in 0 until 64) {
            var d = 0
            val base = 1 + sqi * 36
            for (i in 0 until 36) d += Math.abs(a[base + i] - b[base + i])
            if (d >= 288) return true
        }
        return false
    }

    private class SqFeat(val frac: Float, val meanLum: Float, val grid: FloatArray)

    private fun squareFeat(
        px: IntArray, stride: Int, x0: Int, y0: Int, s: Int,
        skipTopLeft: Boolean, skipBottomRight: Boolean
    ): SqFeat {
        val cnt = IntArray(N * N)
        val tot = IntArray(N * N)
        val lab = s * 34 / 135
        var masked = 0
        var valid = 0
        var lumSum = 0L
        for (dy in 0 until s) {
            val cy = dy * N / s
            val rowBase = (y0 + dy) * stride + x0
            for (dx in 0 until s) {
                if (skipTopLeft && dx < lab && dy < lab) continue
                if (skipBottomRight && dx >= s - lab && dy >= s - lab) continue
                val p = px[rowBase + dx]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                val mx = maxOf(r, maxOf(g, b))
                val mn = minOf(r, minOf(g, b))
                val lum = (299 * r + 587 * g + 114 * b) / 1000
                val sat = (mx - mn) * 100 / maxOf(mx, 1)
                val idx = cy * N + dx * N / s
                tot[idx]++
                valid++
                if (sat < 26 || lum < 55) {
                    cnt[idx]++
                    masked++
                    lumSum += lum
                }
            }
        }
        val grid = FloatArray(N * N) { if (tot[it] == 0) 0f else cnt[it].toFloat() / tot[it] }
        val frac = masked.toFloat() / maxOf(valid, 1)
        val ml = if (masked > 0) lumSum.toFloat() / masked else 0f
        return SqFeat(frac, ml, grid)
    }

    private fun classify(f: SqFeat): Char {
        val white = f.meanLum > 110f
        var best = Float.MAX_VALUE
        var type = 'p'
        for (t in templates) {
            if (t.white != white) continue
            var d = 0f
            for (i in 0 until N * N) {
                val e = f.grid[i] - t.grid[i]
                d += e * e
            }
            if (d < best) {
                best = d
                type = t.type
            }
        }
        return if (white) type.uppercaseChar() else type.lowercaseChar()
    }

    private fun isHighlight(p: Int): Boolean {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        return g - b > 55 && r > 150
    }

    /** Lit l'échiquier affiché à l'écran et renvoie la position (FEN), ou null. */
    fun read(px: IntArray, stride: Int, w: Int, h: Int): Position? {
        if (templates.isEmpty()) { lastError = "modèles absents"; return null }
        val top = findBoardTop(px, stride, w, h)
        if (top < 0) { lastError = "échiquier introuvable"; return null }
        val s = w / 8
        if (top + 8 * s > h) { lastError = "échiquier coupé"; return null }

        val board = Array(8) { CharArray(8) { '.' } }
        val highlights = ArrayList<IntArray>()
        val m = s * 12 / 135

        for (r in 0..7) for (c in 0..7) {
            val x0 = c * s
            val y0 = top + r * s
            val f = squareFeat(px, stride, x0, y0, s, c == 0, r == 7)
            if (f.frac >= 0.05f) board[r][c] = classify(f)

            val pts = arrayOf(
                intArrayOf(x0 + m, y0 + s - m),
                intArrayOf(x0 + s - m, y0 + m),
                intArrayOf(x0 + s - m, y0 + s - m)
            )
            for (pt in pts) {
                if (isHighlight(px[pt[1] * stride + pt[0]])) {
                    highlights.add(intArrayOf(r, c))
                    break
                }
            }
        }

        // Orientation : les Blancs sont en bas si leurs pièces sont plus bas que les Noires.
        var wSum = 0; var wN = 0; var bSum = 0; var bN = 0
        var wK = 0; var bK = 0
        for (r in 0..7) for (c in 0..7) {
            val ch = board[r][c]
            if (ch == '.') continue
            if (ch.isUpperCase()) { wSum += r; wN++; if (ch == 'K') wK++ }
            else { bSum += r; bN++; if (ch == 'k') bK++ }
        }
        if (wK != 1 || bK != 1) {
            lastError = "rois lus : $wK blanc, $bK noir"
            return null
        }
        val whiteAtBottom = wSum.toFloat() / wN >= bSum.toFloat() / bN

        // Plateau "absolu" : abs[0] = rang 8, abs[x][0] = colonne a.
        val abs = Array(8) { i ->
            CharArray(8) { j -> if (whiteAtBottom) board[i][j] else board[7 - i][7 - j] }
        }

        // Camp qui joue : l'inverse de la pièce qui vient d'arriver sur une case surlignée.
        var whiteToMove = true
        for (hl in highlights) {
            val ch = board[hl[0]][hl[1]]
            if (ch != '.') {
                whiteToMove = !ch.isUpperCase()
                break
            }
        }

        val sb = StringBuilder()
        for (i in 0..7) {
            var empty = 0
            for (j in 0..7) {
                val ch = abs[i][j]
                if (ch == '.') empty++ else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(ch)
                }
            }
            if (empty > 0) sb.append(empty)
            if (i < 7) sb.append('/')
        }
        sb.append(if (whiteToMove) " w " else " b ")
        val cs = StringBuilder()
        if (abs[7][4] == 'K' && abs[7][7] == 'R') cs.append('K')
        if (abs[7][4] == 'K' && abs[7][0] == 'R') cs.append('Q')
        if (abs[0][4] == 'k' && abs[0][7] == 'r') cs.append('k')
        if (abs[0][4] == 'k' && abs[0][0] == 'r') cs.append('q')
        sb.append(if (cs.isEmpty()) "-" else cs.toString())
        sb.append(" - 0 1")

        return Position(sb.toString(), top, s, whiteAtBottom)
    }
}

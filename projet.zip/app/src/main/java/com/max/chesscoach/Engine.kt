package com.max.chesscoach

import java.io.BufferedWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Lance le binaire Stockfish et dialogue avec lui en UCI. */
class Engine(private val path: String) {
    private var proc: Process? = null
    private var writer: BufferedWriter? = null
    private val lines = LinkedBlockingQueue<String>()

    fun isAlive(): Boolean = proc?.isAlive == true

    fun start(): Boolean {
        return try {
            val p = ProcessBuilder(path).redirectErrorStream(true).start()
            proc = p
            writer = p.outputStream.bufferedWriter()
            val reader = p.inputStream.bufferedReader()
            thread(isDaemon = true) {
                try {
                    while (true) {
                        val l = reader.readLine() ?: break
                        lines.add(l)
                    }
                } catch (_: Exception) {
                }
            }
            send("uci")
            if (waitFor("uciok", 10000) == null) return false
            send("setoption name Threads value 2")
            send("setoption name Hash value 64")
            send("isready")
            waitFor("readyok", 10000) != null
        } catch (e: Exception) {
            false
        }
    }

    private fun send(cmd: String) {
        val w = writer ?: return
        w.write(cmd)
        w.newLine()
        w.flush()
    }

    private fun waitFor(prefix: String, timeoutMs: Long): String? {
        val end = System.currentTimeMillis() + timeoutMs
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return null
            val l = lines.poll(left, TimeUnit.MILLISECONDS) ?: return null
            if (l.startsWith(prefix)) return l
        }
    }

    /** Meilleur coup au format UCI (ex. "e2e4"), ou null. */
    fun bestMove(fen: String, ms: Int): String? {
        return try {
            lines.clear()
            send("position fen $fen")
            send("go movetime $ms")
            val l = waitFor("bestmove", ms + 5000L) ?: return null
            val m = l.split(" ").getOrNull(1) ?: return null
            if (m.length < 4 || m == "(none)") null else m
        } catch (e: Exception) {
            null
        }
    }

    fun stop() {
        try {
            send("quit")
        } catch (_: Exception) {
        }
        proc?.destroy()
        proc = null
    }
}

package com.max.chesscoach

import java.io.BufferedWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Stockfish en continu : chaque position est analysée en tâche de fond et
 * le meilleur coup est remonté dès les premières profondeurs, puis affiné.
 */
class Engine(private val path: String, private val listener: Listener) {

    interface Listener {
        /** Nouvelle ligne principale : coup UCI, profondeur, score (cp ou mat) du point de vue du camp qui joue. */
        fun onInfo(searchId: Int, move: String, depth: Int, cp: Int?, mate: Int?)
        fun onBest(searchId: Int, move: String?)
    }

    private var proc: Process? = null
    private var writer: BufferedWriter? = null
    private val handshake = LinkedBlockingQueue<String>()
    private val lock = java.lang.Object()
    @Volatile private var generation = 0

    @Volatile private var alive = false
    @Volatile private var searching = false
    @Volatile private var searchId = 0

    /** Numéro que portera la prochaine analyse. */
    fun nextId(): Int = searchId + 1

    fun isAlive(): Boolean = alive && proc?.isAlive == true

    @Synchronized
    fun start(): Boolean {
        val gen = ++generation // les lignes de l'ancien processus seront ignorées
        stopProcess()
        return try {
            val p = ProcessBuilder(path).redirectErrorStream(true).start()
            proc = p
            writer = p.outputStream.bufferedWriter()
            handshake.clear()
            alive = true
            searching = false
            val reader = p.inputStream.bufferedReader()
            thread(isDaemon = true, name = "stockfish-out") {
                try {
                    while (true) {
                        val l = reader.readLine() ?: break
                        if (gen == generation) handle(l)
                    }
                } catch (_: Exception) {
                }
                if (gen == generation) {
                    alive = false
                    synchronized(lock) {
                        searching = false
                        lock.notifyAll()
                    }
                }
            }
            send("uci")
            if (waitHandshake("uciok", 10000) == null) return false
            val threads = (Runtime.getRuntime().availableProcessors() - 2).coerceIn(1, 6)
            send("setoption name Threads value $threads")
            send("setoption name Hash value 128")
            send("isready")
            waitHandshake("readyok", 10000) != null
        } catch (e: Exception) {
            alive = false
            false
        }
    }

    private fun handle(l: String) {
        if (l.startsWith("info ")) {
            parseInfo(l)
        } else if (l.startsWith("bestmove")) {
            val m = l.split(" ").getOrNull(1)
            val id = searchId
            synchronized(lock) {
                searching = false
                lock.notifyAll()
            }
            listener.onBest(id, if (m == null || m == "(none)" || m.length < 4) null else m)
        } else {
            handshake.add(l)
        }
    }

    private fun parseInfo(l: String) {
        if (!searching) return
        val t = l.split(' ')
        var depth = -1
        var cp: Int? = null
        var mate: Int? = null
        var move: String? = null
        var bound = false
        var i = 0
        while (i < t.size) {
            when (t[i]) {
                "depth" -> depth = t.getOrNull(i + 1)?.toIntOrNull() ?: -1
                "multipv" -> if (t.getOrNull(i + 1) != "1") return
                "cp" -> cp = t.getOrNull(i + 1)?.toIntOrNull()
                "mate" -> mate = t.getOrNull(i + 1)?.toIntOrNull()
                "lowerbound", "upperbound" -> bound = true
                "pv" -> { move = t.getOrNull(i + 1); break }
            }
            i++
        }
        val m = move ?: return
        if (bound || depth < 1 || m.length < 4) return
        listener.onInfo(searchId, m, depth, cp, mate)
    }

    private fun send(cmd: String) {
        val w = writer ?: return
        w.write(cmd)
        w.newLine()
        w.flush()
    }

    private fun waitHandshake(prefix: String, timeoutMs: Long): String? {
        val end = System.currentTimeMillis() + timeoutMs
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return null
            val l = handshake.poll(left, TimeUnit.MILLISECONDS) ?: return null
            if (l.startsWith(prefix)) return l
        }
    }

    /** Arrête l'analyse en cours et attend que le moteur soit libre. */
    private fun stopSearch(): Boolean {
        if (!searching) return true
        try { send("stop") } catch (_: Exception) { return false }
        val end = System.currentTimeMillis() + 1500
        synchronized(lock) {
            while (searching) {
                val left = end - System.currentTimeMillis()
                if (left <= 0) return false
                lock.wait(left)
            }
        }
        return true
    }

    /** Lance l'analyse d'une position et renvoie son numéro (ou -1 si le moteur ne répond pas). */
    @Synchronized
    fun analyze(fen: String, ms: Int): Int {
        if (!isAlive() || !stopSearch()) {
            if (!start()) return -1
        }
        return try {
            searchId++
            searching = true
            send("position fen $fen")
            send("go movetime $ms")
            searchId
        } catch (e: Exception) {
            searching = false
            -1
        }
    }

    @Synchronized
    fun cancel() {
        stopSearch()
    }

    private fun stopProcess() {
        try { send("quit") } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
        proc = null
        writer = null
        alive = false
        searching = false
    }

    @Synchronized
    fun stop() {
        stopProcess()
    }
}

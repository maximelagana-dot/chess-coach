package com.max.chesscoach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class ChessService : Service() {

    companion object {
        const val ACTION_STOP = "com.max.chesscoach.STOP"
        const val CHANNEL = "chess_coach"
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var engine: Engine? = null
    private var arrowView: ArrowView? = null
    private var worker: Thread? = null

    @Volatile private var active = false
    private var closing = false
    private var screenW = 0
    private var screenH = 0

    private var bmp: Bitmap? = null
    private var pxArr: IntArray? = null
    private var bytes: ByteArray? = null
    private var stride = 0
    private var haveFrame = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (active) return START_NOT_STICKY

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")

        startInForeground()
        if (data == null) {
            shutdown()
            return START_NOT_STICKY
        }

        try {
            BoardReader.loadTemplates(this)
        } catch (e: Exception) {
            toast("Modèles de pièces introuvables")
            shutdown()
            return START_NOT_STICKY
        }

        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { shutdown() }
                }
            }, main)
            val r = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
            reader = r
            display = p.createVirtualDisplay(
                "chesscoach", screenW, screenH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
        } catch (e: Exception) {
            toast("Capture d'écran impossible : " + e.message)
            shutdown()
            return START_NOT_STICKY
        }

        try {
            setupOverlay(wm, dm)
        } catch (e: Exception) {
            toast("Impossible d'afficher la flèche : " + e.message)
            shutdown()
            return START_NOT_STICKY
        }

        active = true
        val t = Thread { loop() }
        t.isDaemon = true
        worker = t
        t.start()
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Chess Coach", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ChessService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Analyse d'échecs active")
            .setContentText("Une flèche indique le meilleur coup. Touche pour arrêter.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(stopIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupOverlay(wm: WindowManager, dm: DisplayMetrics) {
        val v = ArrowView(this)
        val lp = WindowManager.LayoutParams(
            dm.widthPixels, dm.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        v.visibility = View.INVISIBLE
        wm.addView(v, lp)
        arrowView = v
    }

    private fun onMain(block: () -> Unit) {
        val latch = CountDownLatch(1)
        main.post {
            try {
                block()
            } finally {
                latch.countDown()
            }
        }
        latch.await(2, TimeUnit.SECONDS)
    }

    private fun showArrow(a: FloatArray, b: FloatArray, sq: Int) {
        onMain {
            arrowView?.setArrow(a[0], a[1], b[0], b[1], sq.toFloat())
            arrowView?.visibility = View.VISIBLE
        }
    }

    private fun hideArrow() {
        onMain { arrowView?.visibility = View.INVISIBLE }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    /** Récupère la dernière image de l'écran. */
    private fun grab(): Boolean {
        val r = reader ?: return false
        val img = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (img == null) return haveFrame
        try {
            val plane = img.planes[0]
            val bw = plane.rowStride / plane.pixelStride
            var b = bmp
            if (b == null || b.width != bw || b.height != screenH) {
                b?.recycle()
                b = Bitmap.createBitmap(bw, screenH, Bitmap.Config.ARGB_8888)
                bmp = b
                pxArr = IntArray(bw * screenH)
                bytes = ByteArray(bw * screenH * 4)
            }
            val arr = bytes!!
            val buf = plane.buffer
            buf.rewind()
            buf.get(arr, 0, minOf(buf.remaining(), arr.size))
            b!!.copyPixelsFromBuffer(ByteBuffer.wrap(arr))
            b.getPixels(pxArr!!, 0, bw, 0, 0, bw, screenH)
            stride = bw
            haveFrame = true
        } finally {
            img.close()
        }
        return true
    }

    private fun loop() {
        val path = applicationInfo.nativeLibraryDir + "/libstockfish.so"
        val eng = Engine(path)
        if (!File(path).exists() || !eng.start()) {
            toast("Moteur Stockfish introuvable ou impossible à lancer")
            main.post { shutdown() }
            return
        }
        engine = eng
        toast("Analyse automatique active. Ouvre Chess.com.")

        var shownSig: IntArray? = null
        var prevSig: IntArray? = null
        var lastFen: String? = null
        var lastMove: String? = null
        var arrowVisible = false

        while (active) {
            try {
                Thread.sleep(400)
                if (!grab()) continue
                val px = pxArr ?: continue
                val sig = BoardReader.signature(px, stride, screenW, screenH)
                if (sig == null) {
                    if (arrowVisible) {
                        hideArrow()
                        arrowVisible = false
                    }
                    shownSig = null
                    prevSig = null
                    continue
                }
                val shown = shownSig
                if (shown != null && !BoardReader.changed(shown, sig)) {
                    prevSig = sig
                    continue
                }
                val prev = prevSig
                if (prev == null || BoardReader.changed(prev, sig)) {
                    prevSig = sig
                    continue
                }

                // L'écran a changé puis s'est stabilisé : on relit l'échiquier sans la flèche.
                if (arrowVisible) {
                    hideArrow()
                    arrowVisible = false
                    Thread.sleep(300)
                    grab()
                }
                val px2 = pxArr ?: continue
                val pos = BoardReader.read(px2, stride, screenW, screenH)
                if (pos == null) {
                    lastFen = null
                    lastMove = null
                    shownSig = BoardReader.signature(px2, stride, screenW, screenH)
                    prevSig = shownSig
                    continue
                }

                var move: String? = lastMove
                if (pos.fen != lastFen) {
                    if (!eng.isAlive()) eng.start()
                    move = eng.bestMove(pos.fen, 900)
                    lastFen = pos.fen
                    lastMove = move
                }

                if (move != null) {
                    val a = pos.center(move.substring(0, 2))
                    val b = pos.center(move.substring(2, 4))
                    showArrow(a, b, pos.sq)
                    arrowVisible = true
                    Thread.sleep(300)
                    grab()
                }
                val px3 = pxArr ?: continue
                shownSig = BoardReader.signature(px3, stride, screenW, screenH)
                prevSig = shownSig
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                // on réessaie au tour suivant
            }
        }
    }

    private fun shutdown() {
        if (closing) return
        closing = true
        active = false
        worker?.interrupt()
        try { engine?.stop() } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        arrowView?.let {
            try {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (_: Exception) {
            }
        }
        arrowView = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}

package com.max.chesscoach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import java.nio.ByteOrder
import java.nio.IntBuffer
import java.util.Locale

class ChessService : Service(), Engine.Listener {

    companion object {
        const val ACTION_STOP = "com.max.chesscoach.STOP"
        const val CHANNEL = "chess_coach"
        const val SEARCH_MS = 3000
    }

    /** Où se trouve l'échiquier analysé (coordonnées de capture). */
    private class Geom(val top: Int, val sq: Float, val whiteBottom: Boolean, val whiteToMove: Boolean)

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var engine: Engine? = null
    private var arrowView: ArrowView? = null
    private var worker: Thread? = null

    @Volatile private var active = false
    private var closing = false

    // Écran réel et capture (demi-résolution : 4 fois moins de pixels à lire).
    private var screenW = 0
    private var screenH = 0
    private var capW = 0
    private var capH = 0
    private var scaleX = 2f
    private var scaleY = 2f

    private var pxArr: IntArray? = null
    private var stride = 0
    private var haveFrame = false

    // État de l'analyse, partagé avec le thread du moteur.
    @Volatile private var curSearch = -1
    @Volatile private var curGeom: Geom? = null
    @Volatile private var shownMove: String? = null
    @Volatile private var lastDepth = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (active) return START_NOT_STICKY

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")

        startInForeground()
        if (data == null) {
            shutdown()
            return START_NOT_STICKY
        }

        try {
            BoardReader.loadTemplates(this)
        } catch (e: Exception) {
            toast("Modèles de pièces introuvables")
            shutdown()
            return START_NOT_STICKY
        }

        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        capW = screenW / 2
        capH = screenH / 2
        scaleX = screenW.toFloat() / capW
        scaleY = screenH.toFloat() / capH

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { shutdown() }
                }
            }, main)
            val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3)
            reader = r
            display = p.createVirtualDisplay(
                "chesscoach", capW, capH, maxOf(dm.densityDpi / 2, 120),
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
        } catch (e: Exception) {
            toast("Capture d'écran impossible : " + e.message)
            shutdown()
            return START_NOT_STICKY
        }

        try {
            setupOverlay(wm, dm)
        } catch (e: Exception) {
            toast("Impossible d'afficher la flèche : " + e.message)
            shutdown()
            return START_NOT_STICKY
        }

        active = true
        val t = Thread { loop() }
        t.isDaemon = true
        t.name = "chess-capture"
        worker = t
        t.start()
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Chess Coach", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ChessService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Analyse d'échecs active")
            .setContentText("Une flèche indique le meilleur coup. Touche pour arrêter.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(stopIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupOverlay(wm: WindowManager, dm: DisplayMetrics) {
        val v = ArrowView(this)
        val lp = WindowManager.LayoutParams(
            dm.widthPixels, dm.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        // Android bloque les touches sous une fenêtre superposée plus opaque que 0,8.
        lp.alpha = 0.8f
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        arrowView = v
    }

    // ---------- Affichage ----------

    private var lastStatus = ""

    private fun status(s: String) {
        if (s == lastStatus) return
        lastStatus = s
        main.post { arrowView?.setStatus(s) }
    }

    private fun hideArrow() {
        main.post { arrowView?.clearArrow() }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    private fun center(g: Geom, square: String): FloatArray {
        val file = square[0] - 'a'
        val rank = square[1] - '0'
        val col = if (g.whiteBottom) file else 7 - file
        val row = if (g.whiteBottom) 8 - rank else rank - 1
        return floatArrayOf((col + 0.5f) * g.sq * scaleX, (g.top + (row + 0.5f) * g.sq) * scaleY)
    }

    private fun drawMove(g: Geom, move: String) {
        val a = center(g, move.substring(0, 2))
        val b = center(g, move.substring(2, 4))
        val size = g.sq * scaleX
        main.post { arrowView?.setArrow(a[0], a[1], b[0], b[1], size) }
    }

    private fun pretty(move: String): String {
        val promo = if (move.length > 4) " =" + move[4].uppercaseChar() else ""
        return move.substring(0, 2) + "→" + move.substring(2, 4) + promo
    }

    private fun evalText(g: Geom, cp: Int?, mate: Int?): String {
        if (mate != null) {
            val whiteMates = (mate > 0) == g.whiteToMove
            return "mat en ${Math.abs(mate)} pour les " + (if (whiteMates) "Blancs" else "Noirs")
        }
        val v = (cp ?: 0) * (if (g.whiteToMove) 1 else -1) / 100.0
        return String.format(Locale.FRANCE, "%+.1f", v)
    }

    // ---------- Moteur (appelé depuis le thread de Stockfish) ----------

    override fun onInfo(searchId: Int, move: String, depth: Int, cp: Int?, mate: Int?) {
        if (searchId != curSearch) return
        if (depth < 8 && mate == null) return
        val g = curGeom ?: return
        if (move != shownMove) {
            shownMove = move
            drawMove(g, move)
        }
        if (depth != lastDepth) {
            lastDepth = depth
            val side = if (g.whiteToMove) "Blancs" else "Noirs"
            status("$side : ${pretty(move)}   ${evalText(g, cp, mate)}   (prof. $depth)")
        }
    }

    override fun onBest(searchId: Int, move: String?) {
        if (searchId != curSearch) return
        val g = curGeom ?: return
        if (move == null) {
            hideArrow()
            status("Aucun coup possible (mat ou pat)")
        } else if (move != shownMove) {
            shownMove = move
            drawMove(g, move)
        }
    }

    // ---------- Capture ----------

    /** Récupère la dernière image de l'écran. Renvoie false si l'écran n'a pas changé. */
    private fun grab(): Boolean {
        val r = reader ?: return false
        val img = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return false
        try {
            val plane = img.planes[0]
            val st = plane.rowStride / plane.pixelStride
            val need = st * capH
            var arr = pxArr
            if (arr == null || arr.size != need) {
                arr = IntArray(need)
                pxArr = arr
            }
            val ib = plane.buffer.order(ByteOrder.LITTLE_ENDIAN).asIntBuffer()
            ib.get(arr, 0, minOf(ib.remaining(), need))
            stride = st
            haveFrame = true
        } finally {
            img.close()
        }
        return true
    }

    private var debugSaved = false

    /** Enregistre une fois l'image capturée dans Téléchargements, pour le diagnostic. */
    private fun saveDebug(reason: String) {
        if (debugSaved || Build.VERSION.SDK_INT < 29) return
        val px = pxArr ?: return
        debugSaved = true
        try {
            val bmp = Bitmap.createBitmap(stride, capH, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(IntBuffer.wrap(px))
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "chesscoach_diagnostic_${System.currentTimeMillis()}.png")
                put(MediaStore.Downloads.MIME_TYPE, "image/png")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
            toast("Capture de diagnostic enregistrée dans Téléchargements ($reason)")
        } catch (e: Exception) {
            // diagnostic facultatif
        }
    }

    private fun enginePaths(): List<String> {
        val dir = applicationInfo.nativeLibraryDir
        val fast = File(dir, "libstockfish.so")
        val base = File(dir, "libstockfish_base.so")
        val dotprod = try {
            File("/proc/cpuinfo").readText().contains("asimddp")
        } catch (e: Exception) {
            false
        }
        val list = ArrayList<String>()
        if (dotprod && fast.exists()) list.add(fast.path)
        if (base.exists()) list.add(base.path)
        if (!dotprod && fast.exists()) list.add(fast.path)
        return list
    }

    private fun startEngine(): Engine? {
        for (path in enginePaths()) {
            val e = Engine(path, this)
            if (e.start()) return e
            e.stop()
        }
        return null
    }

    // ---------- Boucle principale ----------

    private var whiteBottom: Boolean? = null
    private var prevAbs: CharArray? = null
    private var prevSide: Boolean? = null
    private var curFen: String? = null

    private fun invalidateAnalysis() {
        curSearch = -1
        curFen = null
        shownMove = null
        engine?.cancel()
        hideArrow()
    }

    private var attempts = 0

    /** Une nouvelle position stable est affichée : on l'analyse. Renvoie true s'il faut réessayer. */
    private fun process(sb: ScreenBoard): Boolean {
        val eng = engine ?: return false
        if (whiteBottom == null || Chess.pieceCount(sb.cells) >= 20) {
            whiteBottom = Chess.guessWhiteBottom(sb.cells) ?: whiteBottom ?: true
        }
        val wb = whiteBottom ?: true
        val abs = Chess.toAbs(sb.cells, wb)

        val err = Chess.validate(abs)
        if (err != null) {
            invalidateAnalysis()
            status("Lecture incertaine : $err")
            saveDebug(err)
            return false
        }

        // Qui joue ? 1) case surlignée du dernier coup, 2) cases qui ont changé, 3) alternance.
        var side: Boolean? = null
        for (i in 0 until 64) {
            if (sb.highlighted[i] && sb.cells[i] != '.') {
                side = !sb.cells[i].isUpperCase()
                break
            }
        }
        val prev = prevAbs
        if (side == null && prev != null && prev.contentEquals(abs)) side = prevSide
        if (side == null) Chess.moverFromDiff(prev, abs)?.let { side = !it }
        var s = side ?: prevSide?.let { !it } ?: true

        // Le camp qui ne joue pas ne peut pas être en échec.
        val wChk = Chess.inCheck(abs, true)
        val bChk = Chess.inCheck(abs, false)
        if (wChk && bChk) {
            invalidateAnalysis()
            status("Lecture incertaine : deux rois en échec")
            saveDebug("deux rois en échec")
            return false
        }
        if (s && bChk) s = false
        if (!s && wChk) s = true

        val fen = Chess.fen(abs, s, Chess.epSquare(prevAbs, abs, s))
        prevAbs = abs
        prevSide = s
        if (fen == curFen) return false
        curFen = fen

        curGeom = Geom(sb.top, sb.sq, wb, s)
        shownMove = null
        lastDepth = 0
        curSearch = eng.nextId()
        hideArrow()
        status((if (s) "Blancs" else "Noirs") + " : calcul…")
        val id = eng.analyze(fen, SEARCH_MS)
        if (id < 0) {
            curSearch = -1
            curFen = null
            status("Moteur indisponible, nouvelle tentative…")
            return true
        }
        curSearch = id
        return false
    }

    private fun loop() {
        val eng = startEngine()
        if (eng == null) {
            toast("Moteur Stockfish introuvable ou impossible à lancer")
            main.post { shutdown() }
            return
        }
        engine = eng
        toast("Analyse automatique active. Ouvre Chess.com.")
        status("Moteur prêt – en attente d'un échiquier")

        var lastBoard: ScreenBoard? = null
        var candKey: String? = null
        var candSince = 0L
        var stableKey: String? = null
        var missSince = 0L
        var lastKey: String? = null

        while (active) {
            try {
                Thread.sleep(40)
                val now = SystemClock.uptimeMillis()
                val fresh = grab()
                if (!haveFrame) continue

                val sb: ScreenBoard?
                if (fresh) {
                    val px = pxArr ?: continue
                    sb = BoardReader.read(px, stride, capW, capH)
                    lastBoard = sb
                } else {
                    sb = lastBoard
                }

                if (sb == null) {
                    if (missSince == 0L) missSince = now
                    val gone = now - missSince
                    if (gone > 400 && stableKey != null) {
                        stableKey = null
                        candKey = null
                        invalidateAnalysis()
                        status("En attente d'un échiquier")
                    }
                    if (gone > 3000) {
                        whiteBottom = null
                        prevAbs = null
                        prevSide = null
                    }
                    continue
                }
                missSince = 0L

                // On attend que l'image soit stable (fin de l'animation de la pièce).
                if (sb.key != candKey) {
                    candKey = sb.key
                    candSince = now
                    continue
                }
                if (now - candSince < 100) continue

                // Moteur arrêté en pleine analyse (plantage) : on relance, 2 fois maximum par position.
                if (sb.key == stableKey && curFen != null && engine?.isAlive() == false && attempts < 2) {
                    attempts++
                    curFen = null
                    stableKey = null
                }
                if (sb.key == stableKey) continue
                if (sb.key != lastKey) {
                    lastKey = sb.key
                    attempts = 0
                }
                stableKey = sb.key
                if (process(sb)) {
                    stableKey = null // réessayer un peu plus tard
                    Thread.sleep(300)
                }
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                status("Erreur : " + (e.message ?: e.javaClass.simpleName))
                stableKey = null
            }
        }
    }

    private fun shutdown() {
        if (closing) return
        closing = true
        active = false
        worker?.interrupt()
        try { engine?.stop() } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        arrowView?.let {
            try {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (_: Exception) {
            }
        }
        arrowView = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}

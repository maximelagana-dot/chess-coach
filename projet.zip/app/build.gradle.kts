plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.max.chesscoach"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.max.chesscoach"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
        ndk { abiFilters += "arm64-v8a" }
    }

    // Clé fixe : les mises à jour s'installent par-dessus l'ancienne version.
    signingConfigs {
        create("fixe") {
            storeFile = file("chesscoach.keystore")
            storePassword = "chesscoach"
            keyAlias = "chesscoach"
            keyPassword = "chesscoach"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixe")
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixe")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs {
            useLegacyPackaging = true
            keepDebugSymbols += "**/*.so"
        }
    }
}

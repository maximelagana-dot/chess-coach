#!/usr/bin/env bash
# Compile Stockfish pour Android (arm64) en deux versions :
#  - libstockfish.so      : optimisée (instructions dotprod, téléphones récents)
#  - libstockfish_base.so : compatible avec tous les arm64
set -euo pipefail
OUT="$(pwd)/app/src/main/jniLibs/arm64-v8a"
mkdir -p "$OUT"
export PATH="$ANDROID_NDK_LATEST_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin:$PATH"
git clone --depth 1 --branch sf_17.1 https://github.com/official-stockfish/Stockfish.git /tmp/sf
cd /tmp/sf/src
make -j4 build ARCH=armv8-dotprod COMP=ndk
cp stockfish "$OUT/libstockfish.so"
make objclean
make -j4 build ARCH=armv8 COMP=ndk
cp stockfish "$OUT/libstockfish_base.so"
ls -la "$OUT"
